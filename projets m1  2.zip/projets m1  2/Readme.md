Readme.md
CAP LIVRAISON

Membres du projet

* Ndeye Adama Sow

Description du projet

CAP LIVRAISON est une application web de suivi de colis destinée à faciliter la gestion et le suivi des livraisons au Sénégal.

Elle permet de consulter les informations relatives aux colis et de suivre leur état d’acheminement.

Technologies utilisées

* HTML5
* CSS3
* JavaScript

Instructions pour exécuter le projet

1. Télécharger le dossier du projet.
2. Ouvrir le fichier Livraison.html dans un navigateur web.
3. Utiliser l’interface pour consulter et suivre les colis.

Année académique

2025-2026