$(document).ready(function () {

    const camion = $("#camion");
    const piste = $(".track");

    let enPause = false;
    let termine = false;

    const etapes = [
        { position: 5, texte: "Colis au départ de l'entrepôt." },
        { position: 47, texte: "Le colis est arrivé au centre de tri." },
        { position: 90, texte: "Le colis est arrivé à destination !" }
    ];

    let etapeActuelle = 0;

    // Mise à jour des étapes
    function actualiserEtape(numero) {

        $(".step").removeClass("active");
        $("#etape" + (numero + 1)).addClass("active");

        $("#statut").text(
            numero === 0 ? "Au départ" :
            numero === 1 ? "En transit" :
            "Livraison terminée"
        );

        $("#message").text(etapes[numero].texte);
    }

    // Fonction de déplacement
    function avancer() {

        if (etapeActuelle >= etapes.length) {
            termine = true;
            $("#message").text("Livraison terminée avec succès !");
            return;
        }

        let position = etapes[etapeActuelle].position;

        actualiserEtape(etapeActuelle);

        camion.animate(
            { left: position + "%" },
            2500,
            "swing",
            function () {

                etapeActuelle++;

                if (etapeActuelle < etapes.length) {
                    avancer();
                } else {
                    termine = true;
                    $("#statut").text("Livré");
                    $("#message").text("🎉 Votre colis a été livré !");
                }

            }
        );
    }

    // Démarrer
    $("#demarrer").click(function () {

        if (termine || etapeActuelle > 0) {
            return;
        }

        enPause = false;
        avancer();

    });

    // Arrêter
    $("#arreter").click(function () {

        camion.stop();

        enPause = true;

        $("#message").text("Livraison mise en pause.");

    });

    // Reprendre
    $("#reprendre").click(function () {

        if (!enPause || termine) {
            return;
        }

        enPause = false;

        $("#message").text("Reprise de la livraison...");

        avancer();

    });

    // Réinitialiser
    $("#reinitialiser").click(function () {

        camion.stop(true, false);

        camion.css("left", "5%");

        etapeActuelle = 0;
        enPause = false;
        termine = false;

        $(".step").removeClass("active");
        $("#etape1").addClass("active");

        $("#statut").text("En attente");
        $("#message").text("Votre livraison est en attente de départ.");

    });

});
